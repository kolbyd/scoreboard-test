<?php $__env->startSection('content'); ?>
    <div id="root" class="flex" style="flex-grow: 1; margin: 1rem">
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/Components/Manager/index.jsx'); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\scoreboard\resources\views/manager.blade.php ENDPATH**/ ?>