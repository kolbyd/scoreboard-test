import {createRoot} from "react-dom/client";
import Button from "@/Components/Manager/Button.jsx";
import Team from "@/Components/Manager/Team.jsx";
import Controls from "@/Components/Manager/Controls.jsx";
import {useEffect, useState} from "react";
import {useSubmit} from "react-router-dom";

export default function Manager() {
    const [minutes, setMinutes] = useState(12);
    const [seconds, setSeconds] = useState(0);

    const [timer, setTimer] = useState(false);

    const [period, setPeriod] = useState(1);

    useEffect( () => {
        if (!timer)
            return;

        const interval = setInterval(() => {
            setSeconds(seconds => (seconds - 0.1).toFixed(1))
        }, 100)

        return () => {
            clearInterval(interval)
        }
    }, [timer]);

    useEffect(() => {
        if (seconds == 0 && minutes == 0) {
            setTimer(false);
        }

        if (seconds < 0 && minutes > 0) {
            setSeconds(59)
            setMinutes(minutes => minutes - 1)
        }
    }, [seconds]);

    useEffect(() => {
        Echo.channel('clock')
            .listen('.clock.started', (msg) => {
                setSeconds(msg.seconds);
                setMinutes(msg.minutes);
                setTimer(true)
            })
            .listen('.clock.stopped', () => {
                setTimer(false)
            })
    }, []);

    return (
        <div style={{display: "flex", flexDirection: "column", minWidth: "100%"}}>
            <div style={{display: "flex", justifyContent: "space-evenly"}}>
                <Team name="Winnipeg Jets" logoUrl="https://upload.wikimedia.org/wikipedia/en/thumb/9/93/Winnipeg_Jets_Logo_2011.svg/1200px-Winnipeg_Jets_Logo_2011.svg.png" />
                <div style={{ display: "flex", flexDirection: "column", color: "white", alignItems: "center", justifyContent: "center", width: "10vw"}}>
                    <div style={{
                        fontSize: "60px",
                        backgroundColor: timer ? "green": "var(--secondary)",
                        padding: "0 1rem",
                        userSelect: "none",
                        borderRadius: "5px",
                        cursor: "pointer"
                    }} onClick={() => setTimer(!timer)}>
                        {
                            minutes > 0 ? (
                                <>{minutes}:{String(Math.ceil(seconds)).padStart(2, "0") }</>
                            ) : (<>{seconds}</>)
                        }

                    </div>
                    <br />
                    <div style={{
                        display: "flex",
                        width: "100%",
                    }}>
                        <p style={{
                            display: "flex",
                            backgroundColor: "var(--secondary)",
                            borderRadius: "5px 0 0 5px",
                            flexGrow: 1,
                            alignItems: "center",
                            justifyContent: "center"}}>
                            Period {period}
                        </p>
                        <div style={{ backgroundColor: "green", flexGrow: 1, padding: "0.5rem 0", cursor: "pointer", textAlign: "center"}}
                             onClick={() => setPeriod(period + 1)}>
                            <i className="fa-solid fa-arrow-up"></i>
                        </div>
                        <div style={{ backgroundColor: "red", borderRadius: "0 5px 5px 0", flexGrow: 1, padding: "0.5rem 0", cursor: "pointer", textAlign: "center"}}
                             onClick={() => {if (period > 1) setPeriod(period - 1)} }>
                            <i className="fa-solid fa-arrow-down"></i>
                        </div>

                    </div>
                </div>
                <Team />
            </div>
            <br />
            <div style={{display: "flex", justifyContent: "space-evenly", columnGap: "2vw"}}>
                <Controls />

                <Controls />
            </div>
        </div>
    );
}

if(document.getElementById('root')){
    createRoot(document.getElementById('root')).render(<Manager />)
}
