import Button from "@/Components/Manager/Button.jsx";

export default function Controls(props) {
    const {team} = props;

    function setScore(increment) {

    }

    return (
        <div style={{display: "flex", justifyContent: "space-evenly",  gap: "6px", flexGrow: 1, flexWrap: "wrap"}}>
            <Button name={"Score +1"} />
            <Button name={"Score -1"} />
            <Button name={"SOG +1"} />
            <Button name={"SOG -1"} />
        </div>
    );
}
