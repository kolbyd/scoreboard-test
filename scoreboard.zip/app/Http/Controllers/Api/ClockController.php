<?php

namespace App\Http\Controllers\Api;

use App\Broadcasting\ClockStarted;
use App\Http\Controllers\Controller;
use Event;
use Illuminate\Http\Request;

class ClockController extends Controller
{
    public function startClock(Request $request)
    {
        $request->validate([
            'minutes' => 'required|integer',
            'seconds' => 'required|integer'
        ]);

        Event::dispatch(new ClockStarted($request->get('minutes'), $request->get('seconds')));
    }
}
